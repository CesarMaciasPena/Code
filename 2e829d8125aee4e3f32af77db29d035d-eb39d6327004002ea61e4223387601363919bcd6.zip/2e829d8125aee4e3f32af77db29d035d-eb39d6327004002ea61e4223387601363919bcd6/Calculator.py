def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y == 0:
        return None
    return x / y

while True:
    print("\nSimple Calculator")
    print("Choose an operation:")
    print("1. Add")
    print("2. Subtract")
    print("3. Multiply")
    print("4. Divide")

    choice = input("Enter choice (1/2/3/4): ").strip()

    if choice not in ['1', '2', '3', '4']:
        print("Invalid choice. Try again.")
        continue

    try:
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        if choice == '1':
            result = add(num1, num2)
        elif choice == '2':
            result = subtract(num1, num2)
        elif choice == '3':
            result = multiply(num1, num2)
        elif choice == '4':
            result = divide(num1, num2)
            if result is None:
                print("Can't divide by zero.")
                continue

        print("Result:", result)

    except ValueError:
        print("Invalid number input. Try again.")
        continue


    again = input("\nWould you like to do another calculation? (yes/no): ").strip().lower()
    if again != "yes":
        print("Goodbye!")
        break
