print("Cloudera chatbot")
print("Type the artist's name and then their performance time.")
print("When you are done, type 'done' to stop entering data.")

artist_times = {}

while True:
    artist = input("Artist name (or type 'done' to finish): ").strip().lower()
    if artist == "done":
        break
    time = input("Performance time: ").strip()
    artist_times[artist] = time

print("Now you can ask for an artist's performance time.")
print("Type 'exit' to quit.")

while True:
    query = input("Artist name: ").strip().lower()
    if query == "exit":
        print("Goodbye!")
        break
    if query in artist_times:
        print(query.title() + " performs at " + artist_times[query])
    else:
        print("I don't have the performance time for that artist.")
